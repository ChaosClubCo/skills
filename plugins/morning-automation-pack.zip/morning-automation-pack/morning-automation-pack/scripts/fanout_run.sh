#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./scripts/fanout_run.sh prompts/01_daily_priorities.txt
# Or:
#   ./scripts/fanout_run.sh prompts/00_MASTER_RUN_PROMPT.txt
#
# Requirements:
# - claude CLI available as: claude
# - gemini CLI available as: gemini
# - chatgpt CLI available as: chatgpt (replace with your actual command if different)

PROMPT_FILE="${1:-}"
if [[ -z "$PROMPT_FILE" ]]; then
  echo "Usage: $0 <prompt_file>"
  exit 1
fi
if [[ ! -f "$PROMPT_FILE" ]]; then
  echo "Prompt file not found: $PROMPT_FILE"
  exit 1
fi

mkdir -p runs
ts="$(date +"%Y%m%d_%H%M%S")"

( cat "$PROMPT_FILE" | claude  > "runs/${ts}_claude.txt"  ) &
( cat "$PROMPT_FILE" | gemini  > "runs/${ts}_gemini.txt"  ) &
( cat "$PROMPT_FILE" | chatgpt > "runs/${ts}_chatgpt.txt" ) &

wait
echo "Done. Outputs in runs/${ts}_*.txt"
