#!/usr/bin/env node
/**
 * Notion DB bootstrap: creates 3 databases + seeds 3+ rows (safe: uses env vars).
 * Required env vars:
 *   NOTION_TOKEN
 *   NOTION_PARENT_PAGE_ID
 *
 * Run:
 *   node scripts/notion_bootstrap.mjs
 */
import https from "https";

const notionToken = process.env.NOTION_TOKEN;
const parentPageId = process.env.NOTION_PARENT_PAGE_ID;

if (!notionToken || !parentPageId) {
  console.error("Missing NOTION_TOKEN or NOTION_PARENT_PAGE_ID");
  process.exit(1);
}

function notion(path, method, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = https.request(
      {
        hostname: "api.notion.com",
        path,
        method,
        headers: {
          Authorization: `Bearer ${notionToken}`,
          "Notion-Version": "2022-06-28",
          "Content-Type": "application/json",
          ...(data ? { "Content-Length": Buffer.byteLength(data) } : {}),
        },
      },
      (res) => {
        let raw = "";
        res.on("data", (c) => (raw += c));
        res.on("end", () => {
          const parsed = raw ? JSON.parse(raw) : {};
          if (res.statusCode >= 200 && res.statusCode < 300) resolve(parsed);
          else reject(new Error(`${res.statusCode} ${raw}`));
        });
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function createDatabase(title, properties) {
  return notion("/v1/databases", "POST", {
    parent: { type: "page_id", page_id: parentPageId.replace(/-/g, "") },
    title: [{ type: "text", text: { content: title } }],
    properties,
  });
}

async function createPage(databaseId, props) {
  return notion("/v1/pages", "POST", {
    parent: { database_id: databaseId },
    properties: props,
  });
}

const isoDate = () => new Date().toISOString().slice(0, 10);

(async () => {
  const today = isoDate();

  const automationRuns = await createDatabase("Automation Runs", {
    Name: { title: {} },
    "Automation Type": {
      select: {
        options: [
          { name: "Daily Priorities" },
          { name: "Morning Brief" },
          { name: "Weekly Synthesis" },
          { name: "Creative Packet" },
          { name: "Health Micro" },
          { name: "Skill Drill" },
        ],
      },
    },
    "Run Date": { date: {} },
    Model: { select: { options: [{ name: "ChatGPT" }, { name: "Claude" }, { name: "Gemini" }] } },
    Input: { rich_text: {} },
    Output: { rich_text: {} },
    "Top Actions": { multi_select: { options: [] } },
    "Timebox Minutes": { number: { format: "number" } },
    Confidence: { select: { options: [{ name: "Low" }, { name: "Medium" }, { name: "High" }] } },
    Blocked: { checkbox: {} },
    Tags: { multi_select: { options: [] } },
    Link: { url: {} },
  });

  const sourcesLibrary = await createDatabase("Sources Library", {
    Title: { title: {} },
    Creator: { rich_text: {} },
    URL: { url: {} },
    Type: { select: { options: [{ name: "Read" }, { name: "Watch" }, { name: "Listen" }] } },
    "Why Now": { rich_text: {} },
    "Suggested Mode": { select: { options: [{ name: "Commute" }, { name: "Break" }, { name: "Weekend" }, { name: "Deep Dive" }] } },
    "Date Added": { date: {} },
    Rating: { select: { options: [{ name: "1" }, { name: "2" }, { name: "3" }, { name: "4" }, { name: "5" }] } },
    "No-Repeat-Until": { date: {} },
  });

  const habitLog = await createDatabase("Habit & Drill Log", {
    Name: { title: {} },
    Type: { select: { options: [{ name: "Health Micro" }, { name: "Skill Drill" }] } },
    Date: { date: {} },
    "Time Minutes": { number: { format: "number" } },
    Completed: { checkbox: {} },
    "Artifact Link": { url: {} },
    "Drill Constraint": { rich_text: {} },
    Metric: { rich_text: {} },
    Notes: { rich_text: {} },
  });

  // Seed rows (3+ examples each)
  await createPage(automationRuns.id, {
    Name: { title: [{ text: { content: "Seed: Daily Priorities" } }] },
    "Automation Type": { select: { name: "Daily Priorities" } },
    "Run Date": { date: { start: today } },
    Model: { select: { name: "ChatGPT" } },
    Input: { rich_text: [{ text: { content: "PRIORITY_1: Add RLS policies\nPRIORITY_2: Fix hook warnings\nPRIORITY_3: Draft onboarding copy" } }] },
    Output: { rich_text: [{ text: { content: "TODAY_TOP_3: ...\nTIMEBOX_PLAN: ...\nRISKS_AND_DEPENDENCIES: ..." } }] },
    Confidence: { select: { name: "Medium" } },
    Blocked: { checkbox: false },
  });

  await createPage(automationRuns.id, {
    Name: { title: [{ text: { content: "Seed: Morning Brief" } }] },
    "Automation Type": { select: { name: "Morning Brief" } },
    "Run Date": { date: { start: today } },
    Model: { select: { name: "Gemini" } },
    Input: { rich_text: [{ text: { content: "FOCUS_AREAS: AI, dev tooling\nAVOID_TOPICS: outrage\nPROJECT_CONTEXT: FlashFusion + INTeract" } }] },
    Output: { rich_text: [{ text: { content: "WORLD_PULSE: ...\nAI_TECH_REALITY_CHECK: ..." } }] },
    Confidence: { select: { name: "High" } },
    Blocked: { checkbox: false },
  });

  await createPage(automationRuns.id, {
    Name: { title: [{ text: { content: "Seed: Weekly Synthesis" } }] },
    "Automation Type": { select: { name: "Weekly Synthesis" } },
    "Run Date": { date: { start: today } },
    Model: { select: { name: "Claude" } },
    Input: { rich_text: [{ text: { content: "WINS: shipped UI\nMISSES: tests\nFRICTION_POINTS: context switching\nCREATIVE_CONSUMED: 2 articles" } }] },
    Output: { rich_text: [{ text: { content: "WINS_WORTH_REPEATING: ...\nSYSTEMS_THAT_FAILED_QUIETLY: ..." } }] },
    Confidence: { select: { name: "Medium" } },
    Blocked: { checkbox: false },
  });

  await createPage(sourcesLibrary.id, {
    Title: { title: [{ text: { content: "Seed: Observability Is a Socio-Technical Problem" } }] },
    Creator: { rich_text: [{ text: { content: "Charity Majors" } }] },
    URL: { url: "https://charity.wtf/" },
    Type: { select: { name: "Read" } },
    "Why Now": { rich_text: [{ text: { content: "Better failure diagnosis for emergent AI + multi-agent systems." } }] },
    "Suggested Mode": { select: { name: "Break" } },
    "Date Added": { date: { start: today } },
    Rating: { select: { name: "5" } },
  });

  await createPage(sourcesLibrary.id, {
    Title: { title: [{ text: { content: "Seed: Taste for Makers" } }] },
    Creator: { rich_text: [{ text: { content: "Paul Graham" } }] },
    URL: { url: "https://paulgraham.com/" },
    Type: { select: { name: "Read" } },
    "Why Now": { rich_text: [{ text: { content: "Sharpens product intuition and design taste." } }] },
    "Suggested Mode": { select: { name: "Commute" } },
    "Date Added": { date: { start: today } },
    Rating: { select: { name: "4" } },
  });

  await createPage(sourcesLibrary.id, {
    Title: { title: [{ text: { content: "Seed: Testability & Design" } }] },
    Creator: { rich_text: [{ text: { content: "Michael Feathers" } }] },
    URL: { url: "https://michaelfeathers.silvrback.com/" },
    Type: { select: { name: "Read" } },
    "Why Now": { rich_text: [{ text: { content: "Helps you structure code so evaluation and change stay cheap." } }] },
    "Suggested Mode": { select: { name: "Deep Dive" } },
    "Date Added": { date: { start: today } },
    Rating: { select: { name: "5" } },
  });

  await createPage(habitLog.id, {
    Name: { title: [{ text: { content: "Seed: 4-minute mobility reset" } }] },
    Type: { select: { name: "Health Micro" } },
    Date: { date: { start: today } },
    "Time Minutes": { number: 4 },
    Completed: { checkbox: false },
    Notes: { rich_text: [{ text: { content: "Neck + shoulders + hips. Mark done if completed once." } }] },
  });

  await createPage(habitLog.id, {
    Name: { title: [{ text: { content: "Seed: 3-minute sunlight + water" } }] },
    Type: { select: { name: "Health Micro" } },
    Date: { date: { start: today } },
    "Time Minutes": { number: 3 },
    Completed: { checkbox: false },
    Notes: { rich_text: [{ text: { content: "Step outside, drink a full glass of water." } }] },
  });

  await createPage(habitLog.id, {
    Name: { title: [{ text: { content: "Seed: Procreate value study (10 min)" } }] },
    Type: { select: { name: "Skill Drill" } },
    Date: { date: { start: today } },
    "Time Minutes": { number: 10 },
    Completed: { checkbox: false },
    "Drill Constraint": { rich_text: [{ text: { content: "1 brush, grayscale only, 10 minutes." } }] },
    Metric: { rich_text: [{ text: { content: "3 value steps clearly separated." } }] },
    Notes: { rich_text: [{ text: { content: "Export image link into Artifact Link when done." } }] },
  });

  console.log("Created DBs:");
  console.log("Automation Runs:", automationRuns.id);
  console.log("Sources Library:", sourcesLibrary.id);
  console.log("Habit & Drill Log:", habitLog.id);
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
