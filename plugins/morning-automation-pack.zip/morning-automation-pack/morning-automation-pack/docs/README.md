Morning Automation Pack

What this is
- A complete set of copy-paste prompts + Notion schemas + scripts to log daily/weekly automation runs.
- Includes a Master Run prompt that asks minimal inputs each morning and outputs a Notion-ready payload.

Folder map
- prompts/: all automation prompts (Master Run, daily/weekly, router, merge)
- notion/: JSON schemas for the 3 Notion databases
- scripts/: Notion bootstrap script + CLI fan-out runner
- examples/: filled examples you can paste to test

Quick start (no coding)
1) Use prompts/00_MASTER_RUN_PROMPT.txt in ChatGPT each morning.
2) Paste the NOTION_PAYLOAD_* block into a new row in Notion → Automation Runs.

Quick start (Notion API)
1) Create an empty Notion page to hold the databases.
2) Export env vars:
   - NOTION_TOKEN
   - NOTION_PARENT_PAGE_ID
3) Run:
   node scripts/notion_bootstrap.mjs

CLI parallel fan-out
- Run:
  ./scripts/fanout_run.sh prompts/01_daily_priorities.txt
- Then paste the three outputs into prompts/08_merge_prompt.txt in your primary model.

Safety
- Never place secrets in Notion Input/Output fields.
- Prefer environment variables for tokens.

Acceptance checks
- Master Run: asks only 5 questions, then outputs Notion payload with stable headings.
- Notion bootstrap: creates 3 DBs and seeds >= 3 rows across them.
- Fan-out: produces 3 output files per run timestamp.
