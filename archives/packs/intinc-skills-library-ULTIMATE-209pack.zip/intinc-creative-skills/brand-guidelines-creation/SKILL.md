---
name: brand-guidelines-creation
description: Create comprehensive brand guidelines documents. Use when create comprehensive brand guidelines documents. Triggers on: brand, guidelines, creation, design, creative work.
version: 1.0.0
allowed-tools: Read, Write
license: MIT
---

# Brand Guidelines Creation

## Purpose
Create comprehensive brand guidelines documents.

## When to Use
- Creating design materials for B2B SaaS/AIaaS
- Brand building and marketing execution
- Customer-facing content creation

## Core Workflow
1. **Brief Analysis** - Understand objectives, audience, and constraints
2. **Research** - Gather competitive intel and audience insights
3. **Creation** - Produce content/design following brand guidelines
4. **Review** - Iterate based on feedback
5. **Deployment** - Publish and measure performance

## Key Deliverables
- Final creative assets (documents, designs, videos)
- Brand-compliant materials
- Performance metrics (engagement, conversion)

## Dependencies
Requires intinc-business-skills for brand guidelines.

## License
MIT License - See LICENSE.txt
