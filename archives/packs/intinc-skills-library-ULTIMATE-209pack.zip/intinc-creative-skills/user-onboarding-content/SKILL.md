---
name: user-onboarding-content
description: Design onboarding flows and content. Use when design onboarding flows and content. Triggers on: user, onboarding, content, content, creative work.
version: 1.0.0
allowed-tools: Read, Write
license: MIT
---

# User Onboarding Content

## Purpose
Design onboarding flows and content.

## When to Use
- Creating content materials for B2B SaaS/AIaaS
- Brand building and marketing execution
- Customer-facing content creation

## Core Workflow
1. **Brief Analysis** - Understand objectives, audience, and constraints
2. **Research** - Gather competitive intel and audience insights
3. **Creation** - Produce content/design following brand guidelines
4. **Review** - Iterate based on feedback
5. **Deployment** - Publish and measure performance

## Key Deliverables
- Final creative assets (documents, designs, videos)
- Brand-compliant materials
- Performance metrics (engagement, conversion)

## Dependencies
Requires intinc-business-skills for brand guidelines.

## License
MIT License - See LICENSE.txt
