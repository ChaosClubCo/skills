---
name: authentication-authorization
description: Implement OAuth 2.0, JWT, RBAC, and SSO authentication. Use when implement oauth 2.0, jwt, rbac, and sso authentication. Triggers on: authentication, authorization, backend, technical implementation.
version: 1.0.0
allowed-tools: Bash, Read, Write
license: MIT
---

# Authentication Authorization

## Purpose
Implement OAuth 2.0, JWT, RBAC, and SSO authentication.

## When to Use
- Building production systems requiring authentication authorization
- Technical architecture decisions for backend
- Implementation guidance for engineering teams

## Core Workflow
1. **Requirements Analysis** - Understand technical requirements and constraints
2. **Architecture Design** - Design solution with best practices
3. **Implementation** - Build with code examples and templates
4. **Testing** - Validate with unit, integration, and performance tests
5. **Documentation** - Create runbooks and technical docs

## Key Deliverables
- Architecture diagrams (Mermaid)
- Code examples (Python/TypeScript/Bash)
- Configuration templates (YAML/JSON)
- Best practices documentation
- Testing strategies

## Dependencies
Foundational technical skill (no IntInc dependencies).

## License
MIT License - See LICENSE.txt
