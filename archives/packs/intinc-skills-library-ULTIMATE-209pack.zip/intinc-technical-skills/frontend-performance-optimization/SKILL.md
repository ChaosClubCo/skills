---
name: frontend-performance-optimization
description: Optimize bundle size, lazy loading, and rendering performance. Use when optimize bundle size, lazy loading, and rendering performance. Triggers on: frontend, performance, optimization, data engineering, technical implementation.
version: 1.0.0
allowed-tools: Bash, Read, Write
license: MIT
---

# Frontend Performance Optimization

## Purpose
Optimize bundle size, lazy loading, and rendering performance.

## When to Use
- Building production systems requiring frontend performance optimization
- Technical architecture decisions for data engineering
- Implementation guidance for engineering teams

## Core Workflow
1. **Requirements Analysis** - Understand technical requirements and constraints
2. **Architecture Design** - Design solution with best practices
3. **Implementation** - Build with code examples and templates
4. **Testing** - Validate with unit, integration, and performance tests
5. **Documentation** - Create runbooks and technical docs

## Key Deliverables
- Architecture diagrams (Mermaid)
- Code examples (Python/TypeScript/Bash)
- Configuration templates (YAML/JSON)
- Best practices documentation
- Testing strategies

## Dependencies
Foundational technical skill (no IntInc dependencies).

## License
MIT License - See LICENSE.txt
